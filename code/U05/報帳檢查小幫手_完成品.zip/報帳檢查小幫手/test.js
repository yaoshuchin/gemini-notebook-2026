// 報帳檢查小幫手｜驗收測試（SPEC.md 第 6 節）
// 用法：node test.js
// 從 index.html 讀出 <script id="rules"> 執行，與網頁使用同一份檢查邏輯。
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const dir = __dirname;
const html = fs.readFileSync(path.join(dir, 'index.html'), 'utf8');
const m = /<script id="rules">([\s\S]*?)<\/script>/.exec(html);
if (!m) { console.error('找不到 index.html 裡的 <script id="rules">'); process.exit(1); }

const ctx = {};
vm.createContext(ctx);
vm.runInContext(m[1], ctx, { filename: 'index.html#rules' });

const csv = fs.readFileSync(path.join(dir, '報帳紀錄_10月.csv'), 'utf8');
const { results, summary } = ctx.checkCSV(csv);

// SPEC.md 第 6 節：預期狀態＋原因關鍵字
const expected = [
  ['T001', '通過', null],
  ['T002', '通過', null],
  ['T003', '通過', null],
  ['T004', '需修正', '每晚超過上限，超額自付 300 元'],
  ['T005', '需修正', '計程車須寫明搭乘原因'],
  ['T006', '退件', '逾期 38 天'],
  ['T007', '通過', null],
  ['T008', '需人工確認', '超過 800 元，請確認部門經理核准'],
  ['T009', '退件', '與 T001 疑似重複'],
  ['T010', '需修正', '發票須載明公司統編 24681357']
];

let pass = 0;
expected.forEach(([id, status, reason]) => {
  const r = results.find(x => x.record['單號'] === id);
  const texts = r ? r.issues.map(i => i.text) : [];
  const okStatus = r && r.status === status;
  const okReason = r && (reason === null ? texts.length === 0 : texts.some(t => t.includes(reason)));
  const ok = okStatus && okReason;
  if (ok) pass++;
  console.log(`${ok ? '✔' : '✘'} ${id}  預期 ${status.padEnd(5, '　')} 實際 ${r ? r.status : '（找不到）'}` +
    `  ${texts.length ? texts.join('；') : '—'}`);
});

const want = { total: 10, '通過': 4, '需修正': 3, '需人工確認': 1, '退件': 2 };
const statsOk = Object.keys(want).every(k => summary[k] === want[k]);
console.log(`\n統計：總 ${summary.total}、通過 ${summary['通過']}、需修正 ${summary['需修正']}、需人工確認 ${summary['需人工確認']}、退件 ${summary['退件']}` +
  `  ${statsOk ? '✔ 與規格書一致' : '✘ 與規格書不一致'}`);

// 網頁內嵌範例資料須與 CSV 檔一致
const sm = /var SAMPLE_CSV = \[([\s\S]*?)\]\.join\('\\n'\);/.exec(html);
const sample = sm ? vm.runInNewContext('[' + sm[1] + ']').join('\n') : '';
const sampleOk = sample === csv.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n').trim();
console.log(`內嵌範例資料與 報帳紀錄_10月.csv ${sampleOk ? '✔ 一致' : '✘ 不一致'}`);

console.log(`\n通過 ${pass}/${expected.length}`);
process.exit(pass === expected.length && statsOk && sampleOk ? 0 : 1);
