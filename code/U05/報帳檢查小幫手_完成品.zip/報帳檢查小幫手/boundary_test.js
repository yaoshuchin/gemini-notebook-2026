// 用法：node boundary_test.js
// 載入與網頁相同的 index.html#rules，CSV 最後欄「預期狀態」為 SPEC 預期。
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const dir = __dirname;
const html = fs.readFileSync(path.join(dir, 'index.html'), 'utf8');
const m = /<script id="rules">([\s\S]*?)<\/script>/.exec(html);
if (!m) { console.error('找不到 index.html 裡的 <script id="rules">'); process.exit(1); }
const ctx = {};
vm.createContext(ctx);
vm.runInContext(m[1], ctx, { filename: 'index.html#rules' });

function parseCSV(text) {
  const rows = []; let row = [], cell = '', quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"' && text[i + 1] === '"') { cell += '"'; i++; }
      else if (c === '"') quoted = false;
      else cell += c;
    } else if (c === '"') quoted = true;
    else if (c === ',') { row.push(cell); cell = ''; }
    else if (c === '\n') { row.push(cell.replace(/\r$/, '')); rows.push(row); row = []; cell = ''; }
    else cell += c;
  }
  if (cell || row.length) { row.push(cell.replace(/\r$/, '')); rows.push(row); }
  return rows;
}

const rows = parseCSV(fs.readFileSync(path.join(dir, '邊界測試.csv'), 'utf8').replace(/^\uFEFF/, ''));
const headers = rows.shift();
const expectedCol = headers.indexOf('預期狀態');
if (expectedCol < 0) { console.error('CSV 缺少預期狀態欄'); process.exit(1); }
const inputHeaders = headers.slice(0, expectedCol);
const inputRows = rows.filter(r => r.some(v => v.trim() !== ''));
const csv = [inputHeaders, ...inputRows.map(r => r.slice(0, expectedCol))]
  .map(r => r.map(v => /[",\r\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v).join(',')).join('\n');
const { results } = ctx.checkCSV(csv);
let pass = 0;
inputRows.forEach((row, i) => {
  const id = row[0] || `空白列${i + 1}`;
  const expected = row[expectedCol];
  const actualRow = results[i];
  const actual = actualRow ? actualRow.status : '（未產生結果列）';
  const ok = expected === actual;
  if (ok) pass++;
  console.log(`${ok ? '✔' : '✘'} ${id}  預期 ${expected}／實際 ${actual}／${ok ? '相符' : '不符'}`);
});
console.log(`\n相符 ${pass}/${inputRows.length}`);
process.exit(pass === inputRows.length ? 0 : 1);
