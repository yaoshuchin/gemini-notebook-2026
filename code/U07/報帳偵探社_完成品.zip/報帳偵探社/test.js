// 報帳偵探社 自動測試（node test.js，免安裝套件）
// 1. 從 index.html 抽出 GAME-DATA 標記內的 JSON
// 2. 10 筆案件欄位與 報帳紀錄_10月.csv 一致
// 3. 10 筆正確答案（狀態＋原因）與 SPEC.md 第 6 節完全一致；罪名對應的規則依據與 SPEC 第 4 節一致
// 4. 每個條文引用（含住宿上限表）都能在規章 html 原文中找到
'use strict';
const fs = require('fs');
const path = require('path');

const HERE = __dirname;
const ROOT = path.resolve(HERE, '..', '..');
const P = {
  game: path.join(HERE, 'index.html'),
  spec: path.join(ROOT, '實作', '報帳檢查小幫手', 'SPEC.md'),
  rule: path.join(ROOT, '練習素材', '企業版_晨曦科技', '_原稿html', '02_出差旅費報支辦法.html'),
  csv: path.join(ROOT, '練習素材', '企業版_晨曦科技', '報帳紀錄_10月.csv')
};

let pass = 0, fail = 0;
function check(name, ok, detail) {
  if (ok) { pass++; console.log('  PASS ' + name); }
  else { fail++; console.log('  FAIL ' + name + (detail ? '  →  ' + detail : '')); }
}

// ---------- 讀檔 ----------
const html = fs.readFileSync(P.game, 'utf8');
const m = html.match(/\/\*GAME-DATA-START\*\/([\s\S]*?)\/\*GAME-DATA-END\*\//);
if (!m) { console.log('FAIL 找不到 GAME-DATA 標記'); process.exit(1); }
const DATA = JSON.parse(m[1]);
const spec = fs.readFileSync(P.spec, 'utf8');
const ruleText = fs.readFileSync(P.rule, 'utf8')
  .replace(/<style[\s\S]*?<\/style>/g, '')
  .replace(/<[^>]+>/g, '')
  .replace(/\s+/g, ' ');
const csvLines = fs.readFileSync(P.csv, 'utf8').replace(/^﻿/, '').split(/\r?\n/).filter(l => l.trim());
const head = csvLines[0].split(',');
const csvRows = csvLines.slice(1).map(l => { const c = l.split(','); const o = {}; head.forEach((h, i) => o[h] = (c[i] || '').trim()); return o; });

const CL = Object.fromEntries(DATA.clauses.map(c => [c.id, c]));
const CH = Object.fromEntries(DATA.charges.map(c => [c.id, c]));

// ---------- 1. 基本結構 ----------
console.log('\n[1] 題目資料結構');
check('案件數 = 10', DATA.cases.length === 10, DATA.cases.length);
check('條文卡數 >= 6', DATA.clauses.length >= 6);
check('罪名含干擾選項（> 6 個）', DATA.charges.length > 6, DATA.charges.length);

// ---------- 2. 與 CSV 一致 ----------
console.log('\n[2] 案件欄位與 報帳紀錄_10月.csv 一致');
check('CSV 也是 10 筆', csvRows.length === 10, csvRows.length);
const MAP = { id: '單號', emp: '員工', rank: '職級', start: '出差日期', end: '出差結束日', filed: '報帳日期', cat: '類別', region: '地區', amount: '金額', reason: '事由', taxid: '發票統編' };
csvRows.forEach(row => {
  const c = DATA.cases.find(x => x.id === row['單號']);
  if (!c) { check(row['單號'] + ' 存在', false); return; }
  const diffs = Object.entries(MAP).filter(([k, h]) => String(c[k]) !== row[h]).map(([k, h]) => h + ':' + c[k] + '≠' + row[h]);
  check(row['單號'] + ' 11 欄全同', diffs.length === 0, diffs.join('；'));
});

// ---------- 3. 與 SPEC §6 一致 ----------
console.log('\n[3] 正確答案與 SPEC.md 第 6 節完全一致');
const sec6 = spec.split(/^## 6\./m)[1].split(/^## 7\./m)[0];
const specRows = {};
sec6.split(/\r?\n/).forEach(l => {
  const mm = l.match(/^\|\s*(T\d{3})\s*\|\s*(.+?)\s*\|\s*(.+?)\s*\|\s*$/);
  if (mm) specRows[mm[1]] = { status: mm[2], reason: mm[3] };
});
check('SPEC 第 6 節解析出 10 筆', Object.keys(specRows).length === 10, Object.keys(specRows).length);
DATA.cases.forEach(c => {
  const s = specRows[c.id], a = c.answer;
  if (!s) { check(c.id + ' 在 SPEC 中', false); return; }
  check(c.id + ' 狀態 ' + a.status, a.status === s.status, 'SPEC=' + s.status);
  check(c.id + ' 原因與 SPEC 逐字相同', a.specReason === s.reason, '遊戲=' + a.specReason + '｜SPEC=' + s.reason);
  check(c.id + ' 判定（通過→沒問題，其餘→有問題）', (s.status === '通過') === (a.verdict === 'ok'));
});
const cnt = st => DATA.cases.filter(c => c.answer.status === st).length;
check('統計 通過4 需修正3 需人工確認1 退件2', cnt('通過') === 4 && cnt('需修正') === 3 && cnt('需人工確認') === 1 && cnt('退件') === 2);

// SPEC §4 規則依據
console.log('\n[3b] 罪名 → 條文 與 SPEC 第 4 節「依據」一致');
const sec4 = spec.split(/^## 4\./m)[1].split(/^## 5\./m)[0];
const ruleBasis = {};
sec4.split(/\r?\n/).forEach(l => {
  const cells = l.split('|').map(x => x.trim());
  if (/^R\d$/.test(cells[1] || '')) ruleBasis[cells[1]] = cells[cells.length - 2];
});
const norm = s => s.replace(/辦法/g, '').replace(/\s+/g, '');
DATA.cases.filter(c => c.answer.verdict === 'bad').forEach(c => {
  const a = c.answer;
  check(c.id + ' 罪名 ' + CH[a.charge].name + ' 的條文 = 罪名預設條文', CH[a.charge].clause === a.clause);
  check(c.id + ' 條文 ' + CL[a.clause].label + ' = SPEC ' + a.rule + ' 依據「' + ruleBasis[a.rule] + '」', norm(CL[a.clause].label) === norm(ruleBasis[a.rule] || ''));
});
check('T009 重複對象為 T001', DATA.cases.find(c => c.id === 'T009').answer.dupOf === 'T001');

// ---------- 4. 條文引用可在規章原文找到 ----------
console.log('\n[4] 條文引用能在 02_出差旅費報支辦法.html 原文找到');
DATA.clauses.forEach(c => {
  check(c.id + ' ' + c.label + ' 原文片段', ruleText.includes(c.quote.replace(/\s+/g, ' ')), c.quote);
  check(c.id + ' 條號「' + c.label.split('條')[0] + '條」存在', ruleText.replace(/\s+/g, '').includes(c.label.split('條')[0].replace(/\s+/g, '') + '條'));
  (c.table || []).forEach(r => r.forEach(cell => check(c.id + ' 表格「' + cell + '」', ruleText.includes(cell))));
});
DATA.cases.forEach(c => (c.answer.refs || []).forEach(id => check(c.id + ' 引用 ' + id + ' 存在', !!CL[id])));

console.log('\n結果：' + pass + ' 通過，' + fail + ' 失敗');
process.exit(fail ? 1 : 0);
