// 晨曦新人闖關 RPG 題庫自動測試（node test.js，不需安裝任何套件）
// 檢查：1) 題庫 JSON 可抽取  2) 每題唯一正確答案  3) 出處引用片段在原文 html 中找得到
//      4) 魔王關 10 筆答案與 報帳檢查小幫手/SPEC.md 第 6 節一致，且報帳欄位與 CSV 一致
const fs = require("fs");
const path = require("path");

const HERE = __dirname;
const ROOT = path.resolve(HERE, "..", ".."); // F:\GeminiNoteBook
const SPEC = path.join(ROOT, "實作", "報帳檢查小幫手", "SPEC.md");
const CSV = path.join(ROOT, "練習素材", "企業版_晨曦科技", "報帳紀錄_10月.csv");

let pass = 0, fail = 0;
const ok = (cond, msg) => { if (cond) pass++; else { fail++; console.log("  ✗ " + msg); } };

// ---------- 1. 抽取題庫 ----------
const html = fs.readFileSync(path.join(HERE, "index.html"), "utf8");
const m = html.match(/\/\*BANK_JSON_START\*\/([\s\S]*?)\/\*BANK_JSON_END\*\//);
if (!m) { console.log("✗ 找不到 BANK_JSON 標記"); process.exit(1); }
let BANK;
try { BANK = JSON.parse(m[1]); } catch (e) { console.log("✗ 題庫 JSON 解析失敗：" + e.message); process.exit(1); }
console.log("✓ 已抽出題庫 JSON");

// ---------- 原文正規化：去標籤、解實體、去所有空白 ----------
const norm = s => s.replace(/[\s\u3000]+/g, "");
function htmlText(file) {
  let t = fs.readFileSync(file, "utf8");
  t = t.replace(/<style[\s\S]*?<\/style>/gi, "").replace(/<script[\s\S]*?<\/script>/gi, "");
  t = t.replace(/<[^>]+>/g, "");
  t = t.replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, "\"")
       .replace(/&#39;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n)).replace(/&amp;/g, "&");
  return norm(t);
}
const DOCS = {};
for (const [k, d] of Object.entries(BANK.docs)) {
  const f = path.join(ROOT, d.file);
  ok(fs.existsSync(f), `原文檔不存在：${f}`);
  DOCS[k] = fs.existsSync(f) ? htmlText(f) : "";
}

function checkSource(id, src) {
  ok(src && DOCS[src.doc] !== undefined, `${id}：source.doc 無效`);
  if (!src || DOCS[src.doc] === undefined) return;
  ok(DOCS[src.doc].includes(norm(src.article)), `${id}：條次「${src.article}」不在 ${BANK.docs[src.doc].title} 原文`);
  ok(Array.isArray(src.quotes) && src.quotes.length > 0, `${id}：缺少 quotes`);
  (src.quotes || []).forEach(q => ok(DOCS[src.doc].includes(norm(q)), `${id}：引用片段在原文找不到 →「${q}」`));
}
function checkChoice(id, options, answer, type) {
  ok(Array.isArray(options) && options.length >= 2, `${id}：選項不足`);
  ok(new Set(options.map(norm)).size === options.length, `${id}：選項重複，正確答案不唯一`);
  ok(Number.isInteger(answer) && answer >= 0 && answer < options.length, `${id}：answer 索引無效`);
  if (type === "tf") ok(options.length === 2 && options[0] === "對" && options[1] === "錯", `${id}：是非題選項須為 [對, 錯]`);
}

// ---------- 2 & 3. 一般關卡 ----------
const ids = new Set();
const summary = [];
for (const [modeKey, mode] of Object.entries(BANK.modes)) {
  for (const lv of mode.levels) {
    const n = lv.questions.length;
    ok(n >= 5 && n <= 6, `${lv.name}：題數 ${n} 不在 5～6`);
    const types = new Set();
    for (const q of lv.questions) {
      ok(!ids.has(q.id), `題號重複：${q.id}`); ids.add(q.id);
      ok(["single", "tf", "scenario", "calc"].includes(q.type), `${q.id}：題型無效`);
      types.add(q.type);
      ok(q.q && q.explain, `${q.id}：缺題幹或解說`);
      checkChoice(q.id, q.options, q.answer, q.type);
      ok(q.source.doc === lv.doc, `${q.id}：出處文件與關卡不符`);
      checkSource(q.id, q.source);
    }
    summary.push(`${modeKey}/${lv.name}：${n} 題（題型：${[...types].join("、")}）`);
  }
  const b = mode.boss;
  for (const it of b.items) {
    ok(!ids.has(it.id), `題號重複：${it.id}`); ids.add(it.id);
    checkChoice(it.id, it.options || b.options, it.answer);
    checkSource(it.id, it.source);
  }
  summary.push(`${modeKey}/${b.name}：${b.items.length} 筆`);
}

// ---------- 4. 魔王關 vs SPEC.md 第 6 節 & CSV ----------
const spec = fs.readFileSync(SPEC, "utf8");
const sec6 = spec.split(/^## 6\./m)[1].split(/^## 7\./m)[0];
const expected = {};
sec6.replace(/^\|\s*(T\d{3})\s*\|\s*([^|]+?)\s*\|/gm, (_, id, st) => { expected[id] = st; });
ok(Object.keys(expected).length === 10, `SPEC 第 6 節應有 10 筆，實得 ${Object.keys(expected).length}`);

const lines = fs.readFileSync(CSV, "utf8").replace(/^\uFEFF/, "").trim().split(/\r?\n/);
const head = lines[0].split(",");
const csvRows = {};
lines.slice(1).forEach(l => { const c = l.split(","); const o = {}; head.forEach((h, i) => o[h] = (c[i] || "").trim()); csvRows[o["單號"]] = o; });

const corpBoss = BANK.modes.corp.boss;
ok(corpBoss.items.length === 10, `企業版魔王應有 10 筆`);
const bossLines = [];
for (const it of corpBoss.items) {
  const got = corpBoss.options[it.answer];
  ok(got === expected[it.id], `${it.id}：遊戲答案「${got}」≠ SPEC「${expected[it.id]}」`);
  const row = csvRows[it.id];
  ok(!!row, `${it.id}：CSV 找不到`);
  if (row) head.forEach(h => ok(String(it.record[h] ?? "") === row[h], `${it.id}.${h}：遊戲「${it.record[h]}」≠ CSV「${row[h]}」`));
  bossLines.push(`${it.id}=${got}`);
}

// ---------- 結果 ----------
console.log("\n題庫概況：");
summary.forEach(s => console.log("  - " + s));
console.log("魔王關判定：" + bossLines.join("、"));
const qTotal = Object.values(BANK.modes).reduce((a, md) => a + md.levels.reduce((x, l) => x + l.questions.length, 0) + md.boss.items.length, 0);
console.log(`總題數（含魔王）：${qTotal}`);
console.log(`\n檢查項目：通過 ${pass}，失敗 ${fail}`);
console.log(fail === 0 ? "✅ ALL TESTS PASSED" : "❌ TESTS FAILED");
process.exit(fail === 0 ? 0 : 1);
