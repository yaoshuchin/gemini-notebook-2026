// 難搞同事對話練習｜劇本自動檢查（node test.js，不需安裝任何套件）
// 檢查：JSON 可解析、無斷頭節點、無孤兒節點、無循環、每條分支都走得到結局、
//       每回合至少一個最佳回應、每段引用的條文片段都能在規章／講義 html 原文找到。
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', '..');
const SRC = {
  '01_請假辦法.html': path.join(ROOT, '練習素材', '企業版_晨曦科技', '_原稿html', '01_請假辦法.html'),
  '02_出差旅費報支辦法.html': path.join(ROOT, '練習素材', '企業版_晨曦科技', '_原稿html', '02_出差旅費報支辦法.html'),
  '03_資訊安全與AI工具使用規範.html': path.join(ROOT, '練習素材', '企業版_晨曦科技', '_原稿html', '03_資訊安全與AI工具使用規範.html'),
  '講義_水的循環.html': path.join(ROOT, '練習素材', '教育版_水的循環', '講義_水的循環.html'),
};

let pass = 0, fail = 0;
const errors = [];
function check(cond, msg) { if (cond) pass++; else { fail++; errors.push(msg); } }

// 1. 抽出內嵌劇本
const html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
const m = html.match(/<!-- SCENARIOS_JSON_BEGIN -->\s*<script type="application\/json" id="scenario-data">([\s\S]*?)<\/script>\s*<!-- SCENARIOS_JSON_END -->/);
if (!m) { console.error('✗ 找不到 SCENARIOS_JSON_BEGIN/END 標記'); process.exit(1); }
let DATA;
try { DATA = JSON.parse(m[1]); } catch (e) { console.error('✗ 劇本 JSON 解析失敗：' + e.message); process.exit(1); }
check(true, '');

// 2. 讀原文：去標籤、解實體、去所有空白
function normalize(s) {
  return s.replace(/<(script|style)[\s\S]*?<\/\1>/gi, '')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&')
    .replace(/[\s　]+/g, '');
}
const TEXT = {};
for (const [k, d] of Object.entries(DATA.docs)) {
  const p = SRC[d.file];
  check(p && fs.existsSync(p), `docs.${k} 對應的原文檔不存在：${d.file}`);
  if (p && fs.existsSync(p)) TEXT[k] = normalize(fs.readFileSync(p, 'utf8'));
}

const KINDS = new Set(['best', 'wrong', 'tone', 'lenient']);
const ENDS = new Set(['win', 'partial', 'lose']);
let totalNodes = 0, totalChoiceNodes = 0, totalEndNodes = 0, totalChoices = 0, totalCites = 0, totalPaths = 0;

for (const sc of DATA.scenarios) {
  const tag = `[${sc.id}]`;
  const nodes = sc.nodes;
  const ids = Object.keys(nodes);
  totalNodes += ids.length;
  check(nodes[sc.start], `${tag} start 節點 ${sc.start} 不存在`);
  check(Array.isArray(sc.npc.faces) && sc.npc.faces.length === 5, `${tag} 表情頭像需 5 個`);

  for (const id of ids) {
    const n = nodes[id];
    if (n.end) {
      totalEndNodes++;
      check(ENDS.has(n.end), `${tag} ${id} 結局類型錯誤：${n.end}`);
      check(!n.choices, `${tag} ${id} 結局節點不應有選項`);
      continue;
    }
    totalChoiceNodes++;
    check(Array.isArray(n.choices) && n.choices.length >= 3 && n.choices.length <= 4, `${tag} ${id} 選項數需 3～4 個`);
    const bests = n.choices.filter(c => c.k === 'best');
    check(bests.length >= 1, `${tag} ${id} 沒有最佳回應`);
    for (const b of bests) check(Array.isArray(b.cite) && b.cite.length > 0, `${tag} ${id} 最佳回應沒有附條文引用`);
    n.choices.forEach((c, i) => {
      totalChoices++;
      const ct = `${tag} ${id}#${i}`;
      check(KINDS.has(c.k), `${ct} 回應類型錯誤：${c.k}`);
      check(Array.isArray(c.s) && c.s.length === 4 && c.s.every(v => Number.isInteger(v) && v >= 0 && v <= 3), `${ct} 評分 s 需為 4 個 0～3 整數`);
      check(typeof c.m === 'number', `${ct} 缺情緒變化 m`);
      check(c.t && c.fb && c.r, `${ct} 缺 t/fb/r 文字`);
      check(nodes[c.next], `${ct} 斷頭：next=${c.next} 不存在`);
      if (c.k === 'best') check(c.s.every(v => v === 3), `${ct} 最佳回應四向度應皆為 3`);
      for (const q of (c.cite || [])) {
        totalCites++;
        check(TEXT[q.doc] !== undefined, `${ct} 引用來源 ${q.doc} 不存在`);
        const needle = q.q.replace(/[\s　]+/g, '');
        check(TEXT[q.doc] && TEXT[q.doc].includes(needle), `${ct} 引用在原文找不到：「${q.q}」（${q.doc}）`);
      }
    });
  }

  // 3. 可達性（無孤兒）
  const seen = new Set();
  const stack = [sc.start];
  while (stack.length) {
    const id = stack.pop();
    if (seen.has(id) || !nodes[id]) continue;
    seen.add(id);
    (nodes[id].choices || []).forEach(c => stack.push(c.next));
  }
  for (const id of ids) check(seen.has(id), `${tag} 孤兒節點（走不到）：${id}`);

  // 4. 列舉所有路徑：每條都要到結局、不得循環
  const reached = new Set();
  let paths = 0, hasWinAllBest = false;
  function walk(id, visiting, allBest) {
    const n = nodes[id];
    if (!n) return;
    if (visiting.has(id)) { check(false, `${tag} 偵測到循環：${[...visiting, id].join('→')}`); return; }
    if (n.end) { paths++; reached.add(n.end); if (n.end === 'win' && allBest) hasWinAllBest = true; return; }
    visiting.add(id);
    for (const c of n.choices) walk(c.next, visiting, allBest && c.k === 'best');
    visiting.delete(id);
  }
  walk(sc.start, new Set(), true);
  totalPaths += paths;
  check(paths > 0, `${tag} 沒有任何可完成的路徑`);
  check(hasWinAllBest, `${tag} 全選最佳回應無法到達 win 結局`);
  for (const e of ENDS) check(reached.has(e), `${tag} 結局 ${e} 走不到`);
  console.log(`${tag} ${sc.title}：節點 ${ids.length}（對話 ${ids.filter(i => !nodes[i].end).length}／結局 ${ids.filter(i => nodes[i].end).length}），完整路徑 ${paths} 條`);
}

// 5. 版面規格抽查
check(!/<(script|link)[^>]+(src|href)=["']https?:/i.test(html), 'index.html 不得引用外部網路資源');
check(DATA.scenarios.length >= 5 && DATA.scenarios.some(s => s.category === '教育'), '至少 5 個情境且含教育版');

console.log('—'.repeat(40));
console.log(`情境 ${DATA.scenarios.length} 個｜節點 ${totalNodes}（對話 ${totalChoiceNodes}、結局 ${totalEndNodes}）｜選項 ${totalChoices}｜條文引用 ${totalCites} 段｜完整路徑 ${totalPaths} 條`);
if (fail) {
  errors.forEach(e => console.log('✗ ' + e));
  console.log(`結果：${pass} 通過，${fail} 失敗`);
  process.exit(1);
}
console.log(`結果：全部 ${pass} 項檢查通過 ✓`);
